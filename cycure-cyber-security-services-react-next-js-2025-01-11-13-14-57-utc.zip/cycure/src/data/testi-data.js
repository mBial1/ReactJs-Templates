const testi_data = [
    {
        id: 1,
        quite: "/assets/img/icons/quote.png",
        des: (<>“Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id
            quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae”
        </>),
        avatar: "/assets/img/others/avatar01.png",
        name: "Peterson / Ceo & Founder",
        rating: ["fas fa-star", "fas fa-star", "fas fa-star", "fas fa-star", "fas fa-star",]
    },
    {
        id: 2,
        quite: "/assets/img/icons/quote.png",
        des: (<>“Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id
            quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae”
        </>),
        avatar: "/assets/img/others/avatar02.png",
        name: "Rensona / Ceo & Founder",
        rating: ["fas fa-star", "fas fa-star", "fas fa-star", "fas fa-star", "fas fa-star",]
    },
    {
        id: 3,
        quite: "/assets/img/icons/quote.png",
        des: (<>“Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id
            quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae”
        </>),
        avatar: "/assets/img/others/avatar03.png",
        name: "Markline / Ceo & Founder",
        rating: ["fas fa-star", "fas fa-star", "fas fa-star", "fas fa-star", "fas fa-star",]
    },
]

export default testi_data;