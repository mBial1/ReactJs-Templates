const team_data = [
    {
        id: 1,
        img: "/assets/img/team/team_01.jpg",
        name: "Morgan Cooper",
        designation: "Ceo & founder"
    },
    {
        id: 2,
        img: "/assets/img/team/team_02.jpg",
        name: "Amanda Brown",
        designation: "Ceo & founder"
    },
    {
        id: 3,
        img: "/assets/img/team/team_03.jpg",
        name: "Harry Peterson",
        designation: "Security Head"
    },
    {
        id: 4,
        img: "/assets/img/team/team_04.jpg",
        name: "Michel Donald",
        designation: "Programmer"
    },
    {
        id: 5,
        img: "/assets/img/team/team_05.jpg",
        name: "David Harrison",
        designation: "Programmer"
    },
    {
        id: 6,
        img: "/assets/img/team/team_06.jpg",
        name: "Duglas Rovland",
        designation: "Cyber analyst"
    },
    {
        id: 7,
        img: "/assets/img/team/team_07.jpg",
        name: "Kiara Montesino",
        designation: "Programmer"
    },
    {
        id: 8,
        img: "/assets/img/team/team_08.jpg",
        name: "Christina Jonson",
        designation: "Ethical Hacker"
    },
]

export default team_data;