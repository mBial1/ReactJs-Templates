const price_data = [
    {
        id: 1,
        duration: "Monthly",
        price: 499,
        des: (<>Nam libero tempore soluta nobis eligendi quod maxime placeat possimus assumenda</>),
        btn: "Get started now",
        package_name: "Personal",
        list: [
            "Encrypted Transactions", "24/7 Support Service",
            "Automated Daily Backup", "Free Hardware Included",
            "Scan Every 12 Hours",
        ]
    },
    {
        id: 2,
        duration: "Monthly",
        price: 1099,
        des: (<>Nam libero tempore soluta nobis eligendi quod maxime placeat possimus assumenda</>),
        btn: "Get started now",
        package_name: "Startup",
        list: [
            "Encrypted Transactions", "24/7 Support Service",
            "Automated Daily Backup", "Free Hardware Included",
            "Scan Every 12 Hours",
        ]
    },
    {
        id: 3,
        duration: "Monthly",
        price: 1599,
        des: (<>Nam libero tempore soluta nobis eligendi quod maxime placeat possimus assumenda</>),
        btn: "Get started now",
        package_name: "Company",
        list: [
            "Encrypted Transactions", "24/7 Support Service",
            "Automated Daily Backup", "Free Hardware Included",
            "Scan Every 12 Hours",
        ]
    }
]

export default price_data;