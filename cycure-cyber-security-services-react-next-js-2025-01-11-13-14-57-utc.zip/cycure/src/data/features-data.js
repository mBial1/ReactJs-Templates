const feature_data = [
    {
        id: 1,
        icon: "flaticon-warning",
        title: "Malware Detection Removal",
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil impedit quo minus quod</>),
        btn: "Learn More"
    },
    {
        id: 2,
        icon: "flaticon-server-1",
        title: "Content Delivery Network",
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil impedit quo minus quod</>),
        btn: "Learn More"
    },
    {
        id: 3,
        icon: "flaticon-admin",
        title: "Anytime Security Support",
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil impedit quo minus quod</>),
        btn: "Learn More"
    },
    {
        id: 4,
        icon: "flaticon-web-security",
        title: "Managed Website Application",
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil impedit quo minus quod</>),
        btn: "Learn More"
    }
]

export default feature_data;