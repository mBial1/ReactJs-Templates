const tabs_data = [  
    {
        id: 1,
        title: 'Banking Security',
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil quo minus id
            quod maxime placeat facere possimus assumenda omnis dolor repellendus.
            Temporibus autem quibusdam et aut officiis nam libero tempore itaque earum
            rerum hic tenetur
        </>),
        list: [
            "Focus on The Basics", "Educate Customers",
            "Tighten Internal Controls", "Be Proactive",
        ]

    },
    {
        id: 2,
        title: 'Manufacturing',
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil quo minus id
            quod maxime placeat facere possimus assumenda omnis dolor repellendus.
            Temporibus autem quibusdam et aut officiis nam libero tempore itaque earum
            rerum hic tenetur
        </>),
        list: [
            "Focus on The Basics", "Educate Customers",
            "Tighten Internal Controls", "Be Proactive",
        ]

    },
    {
        id: 3,
        title: 'Oil And Gas',
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil quo minus id
            quod maxime placeat facere possimus assumenda omnis dolor repellendus.
            Temporibus autem quibusdam et aut officiis nam libero tempore itaque earum
            rerum hic tenetur
        </>),
        list: [
            "Focus on The Basics", "Educate Customers",
            "Tighten Internal Controls", "Be Proactive",
        ]

    },
    {
        id: 4,
        title: 'Insurance Security',
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil quo minus id
            quod maxime placeat facere possimus assumenda omnis dolor repellendus.
            Temporibus autem quibusdam et aut officiis nam libero tempore itaque earum
            rerum hic tenetur
        </>),
        list: [
            "Focus on The Basics", "Educate Customers",
            "Tighten Internal Controls", "Be Proactive",
        ]

    },
    {
        id: 5,
        title: 'Healthcare Security',
        des: (<>Nam libero tempore, cum soluta nobis eligendi optio cumque nihil quo minus id
            quod maxime placeat facere possimus assumenda omnis dolor repellendus.
            Temporibus autem quibusdam et aut officiis nam libero tempore itaque earum
            rerum hic tenetur
        </>),
        list: [
            "Focus on The Basics", "Educate Customers",
            "Tighten Internal Controls", "Be Proactive",
        ]

    },
];

export default tabs_data;