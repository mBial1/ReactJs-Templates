const answer_question_data = [
    {
        id: 1,
        question: " How Is Encryption Different From Hacking?",
        answer: (
            <>
                Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod facere maxime placeat possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet voluptates
            </>
        ),
    },
    {
        id: 2,
        question: " What Steps Will You Take to Secure Your Server?",
        answer: (
            <>
                Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod facere maxime placeat possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet voluptates
            </>
        ),
    },
    {
        id: 3,
        question: "What Is Firewall & Why It Is Used?",
        answer: (
            <>
                Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod facere maxime placeat possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet voluptates
            </>
        ),
    },
    {
        id: 4,
        question: "Do Mobile Devices Present Security Risk?",
        answer: (
            <>
                Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod facere maxime placeat possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet voluptates
            </>
        ),
    },
    {
        id: 5,
        question: "How Is Encryption Different From Hacking?",
        answer: (
            <>
                Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod facere maxime placeat possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet voluptates
            </>
        ),
    },
    {
        id: 6,
        question: "What Are the Costs of a Cyber Attack?",
        answer: (
            <>
                Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod facere maxime placeat possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet voluptates
            </>
        ),
    },
];
export default answer_question_data;