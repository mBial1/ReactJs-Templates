const shop_data = [
    {
        id: 1,
        thumb: "/assets/img/shop/shop_item01.jpg",
        price: 40.00,
        title: "Extended Cable",
        btn: "Add to cart"
    },
    {
        id: 2,
        thumb: "/assets/img/shop/shop_item02.jpg",
        price: 29.00,
        title: "Wireless Keyboards",
        btn: "Add to cart"
    },
    {
        id: 3,
        thumb: "/assets/img/shop/shop_item03.jpg",
        price: 39.00,
        title: "Presentation Remote",
        btn: "Add to cart"
    },
    {
        id: 4,
        thumb: "/assets/img/shop/shop_item04.jpg",
        price: 39.00,
        title: "Bluetooth Headset",
        btn: "Add to cart"
    },
    {
        id: 5,
        thumb: "/assets/img/shop/shop_item05.jpg",
        price: 39.00,
        title: "Screen Share Device",
        btn: "Add to cart"
    },
    {
        id: 6,
        thumb: "/assets/img/shop/shop_item06.jpg",
        price: 39.00,
        title: "Expansion Microphone",
        btn: "Add to cart"
    },
    {
        id: 7,
        thumb: "/assets/img/shop/shop_item07.jpg",
        price: 39.00,
        title: "Wireless Mouse",
        btn: "Add to cart"
    },
    {
        id: 8,
        thumb: "/assets/img/shop/shop_item08.jpg",
        price: 39.00,
        title: "Bluetooth Speaker",
        btn: "Add to cart"
    },
    {
        id: 9,
        thumb: "/assets/img/shop/shop_item09.jpg",
        price: 39.00,
        title: "Streaming Camera",
        btn: "Add to cart"
    },
    {
        id: 10,
        thumb: "/assets/img/shop/shop_item10.jpg",
        price: 39.00,
        title: "Wireless Phone Charger",
        btn: "Add to cart"
    },
    {
        id: 11,
        thumb: "/assets/img/shop/shop_item11.jpg",
        price: 39.00,
        title: "Astro Headset Case",
        btn: "Add to cart"
    },
    {
        id: 12,
        thumb: "/assets/img/shop/shop_item12.jpg",
        price: 39.00,
        title: "Wired Earbuds",
        btn: "Add to cart"
    },
]

export default shop_data;