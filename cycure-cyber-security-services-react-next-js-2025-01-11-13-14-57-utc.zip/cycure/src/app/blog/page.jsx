import Blog from '@/components/blogs/blog-standard'
import React from 'react'

const page = () => {
  return (
    <>
      <Blog/>
    </>
  )
}

export default page
