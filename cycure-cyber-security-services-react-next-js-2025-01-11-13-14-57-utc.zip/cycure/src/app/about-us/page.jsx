import About from "@/components/about/about"

const page = () => {
  return (
    <>
      <About/>
    </>
  )
}

export default page
