import ShopDetails from '@/components/shop-details'

const page = () => {
  return (
    <>
      <ShopDetails/>
    </>
  )
}

export default page
