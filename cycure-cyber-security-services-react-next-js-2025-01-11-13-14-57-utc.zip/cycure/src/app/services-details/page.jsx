import ServicesDetails from '@/components/services-details'

const page = () => {
    return (
        <>
            <ServicesDetails />
        </>
    )
}

export default page
