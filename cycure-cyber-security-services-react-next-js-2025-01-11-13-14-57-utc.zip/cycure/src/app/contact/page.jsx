import Contact from "@/components/contact"

const page = () => {
    return (
        <>
            <Contact />
        </>
    )
}

export default page
