import HomeTwo from '@/components/homes/home-two/home-two'

const page = () => {
  return (
    <>
      <HomeTwo/>
    </>
  )
}

export default page
