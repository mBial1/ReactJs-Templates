import FAQ from "@/components/faq/faq"

const page = () => {
    return (
        <>
            <FAQ />
        </>
    )
}

export default page
