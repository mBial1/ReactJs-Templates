import HomeThree from "@/components/homes/home-three/home-three"

const page = () => {
  return (
    <>
      <HomeThree/>
    </>
  )
}

export default page
