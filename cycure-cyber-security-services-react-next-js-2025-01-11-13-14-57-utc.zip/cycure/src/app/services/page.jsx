import Services from '@/components/services/services'

const page = () => {
    return (
        <>
            <Services/>
        </>
    )
}

export default page
