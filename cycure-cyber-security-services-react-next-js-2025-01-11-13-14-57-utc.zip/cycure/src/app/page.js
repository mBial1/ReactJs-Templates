import Home from "../components/homes/home/home"
export default function page() {
  return (
    <>
      <Home/>
    </>
  );
}
