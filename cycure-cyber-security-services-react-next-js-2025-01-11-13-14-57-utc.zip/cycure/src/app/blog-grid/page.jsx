import BlogGrid from "@/components/blogs/blog-grid"

const page = () => {
  return (
    <>
      <BlogGrid/>
    </>
  )
}

export default page
