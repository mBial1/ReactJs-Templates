import Pricing from "@/components/pricing/pricing"

const page = () => {
    return (
        <>
            <Pricing />
        </>
    )
}

export default page
