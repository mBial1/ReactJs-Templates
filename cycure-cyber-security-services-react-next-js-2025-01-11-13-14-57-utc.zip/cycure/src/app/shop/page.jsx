import Shop from '@/components/shop'

const page = () => {
  return (
    <>
      <Shop/>
    </>
  )
}

export default page
