import BlogDetails from "../../components/blogs/blog-details"

const page = () => {
  return (
    <>
      <BlogDetails/>
    </>
  )
}

export default page
