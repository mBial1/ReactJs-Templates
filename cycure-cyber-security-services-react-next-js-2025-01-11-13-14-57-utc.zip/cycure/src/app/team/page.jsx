import Team from "@/components/team/team"

const page = () => {
    return (
        <>
            <Team />
        </>
    )
}

export default page
