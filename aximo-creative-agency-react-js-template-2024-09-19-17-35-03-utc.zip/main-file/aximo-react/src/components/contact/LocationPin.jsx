export default function LocationPin() {
	return (
		<div className="pin">
			<i className="fas fa-map-marker"></i>
		</div>
	);
}
