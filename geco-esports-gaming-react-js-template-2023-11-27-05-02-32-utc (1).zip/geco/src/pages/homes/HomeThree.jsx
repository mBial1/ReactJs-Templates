import React from 'react'
import IndexThree from '../../components/index/indexthree/IndexThree';
function HomeThree() {
  return (
	<IndexThree/>
  )
}

export default HomeThree