import React from 'react'
import IndexSix from '../../components/index/indexsix/IndexSix'

const HomeSix = () => {
  return (
     <IndexSix/>
  )
}

export default HomeSix