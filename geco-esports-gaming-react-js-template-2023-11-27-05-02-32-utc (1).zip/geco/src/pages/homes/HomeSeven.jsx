import React from 'react'
import IndexSeven from '../../components/index/indexseven/IndexSeven'

const HomeSeven = () => {
  return (
    <IndexSeven/>
  )
}

export default HomeSeven