import React from 'react'
import IndexFour from '../../components/index/indexfour/IndexFour'

const HomeFour = () => {
  return (
   <IndexFour/>
  )
}

export default HomeFour