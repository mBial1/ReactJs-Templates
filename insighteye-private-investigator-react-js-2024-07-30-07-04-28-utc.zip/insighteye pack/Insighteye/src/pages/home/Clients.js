import React from 'react';
import ClientsSlider from '../../components/slider/ClientsSlider';


const Clients = (props) => {
    return (
        
        <>
        {/* clients-section*/}
        <section className="clients-section">
            <div className="auto-container">
                <ClientsSlider/>
            </div>
        </section>
        {/*clients-section end */}
        </>


    );
}

export default Clients;
















            
